
def main():
    from . import cli_interface
    cli_interface.main()

if __name__ == "__main__":
    main()
